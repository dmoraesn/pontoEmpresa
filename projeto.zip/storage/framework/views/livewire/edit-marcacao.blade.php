<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Marcacao;
use Carbon\Carbon;

class EditMarcacao extends Component
{
    public $marcacaoId;
    public $tipo;
    public $data_hora;
    public $origem;

    protected $rules = [
        'tipo'      => 'required|in:entrada,saida',
        'data_hora' => 'required|date',
        'origem'    => 'nullable|string|max:50',
    ];

    public function mount(Marcacao $marcacao)
    {
        $this->marcacaoId = $marcacao->id;
        $this->tipo       = $marcacao->tipo;
        $this->data_hora  = $marcacao->data_hora->format('Y-m-d\TH:i');
        $this->origem     = $marcacao->origem;
    }

    public function update()
    {
        $this->validate();

        $marcacao = Marcacao::findOrFail($this->marcacaoId);
        $marcacao->update([
            'tipo'      => $this->tipo,
            'data_hora' => Carbon::parse($this->data_hora),
            'origem'    => $this->origem ?? $marcacao->origem,
        ]);

        session()->flash('success', 'Marcação atualizada com sucesso!');
        return redirect()->route('usuarios.ponto.index', $marcacao->usuario_id);
    }

    public function render()
    {
        return view('livewire.edit-marcacao');
    }
}
